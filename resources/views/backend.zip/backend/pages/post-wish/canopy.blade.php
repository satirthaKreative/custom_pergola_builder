@extends('backend.app')
@section('content')
<section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>
          Canopy Post Wish View
          <!-- Pick a Footprint (outside post to post) -->
          </h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
            <li class="breadcrumb-item active">Canopy Post Wish View</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
</section>
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
    <div class="row">
        <!-- left column -->
        <div class="col-md-12">
        <div class="card card-success">
            <div class="card-header">
              <h3 class="card-title">Canopy Post Wish View</h3>
              <span class="float-right"><a class="btn btn-danger btn-sm" onclick="add_post_wish_canopy_fx()" style="margin-right: 10px;">Add Posts Wish Canopy</a></span>
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive scroll-demo-table p-0" >
            <div style="padding: 10px">
              <table class="table table-hover text-nowrap" id="show-piller-post-id">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Piller Post</th>
                    <th>Video Link</th>
                    <th>Description</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody id="canopy-tbl-id">
                  <tr>
                    <td colspan="5"><center class="text-info"><i class="fa fa-spinner"></i> Loading data's</center></td>
                  </tr>
                </tbody>
              </table>
              </div>
            </div>
            <!-- /.card-body -->
          </div>
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->

    </div><!-- /.container-fluid -->
</section>
  <!-- /.content -->

<!-- Post Wish Canopy Model -->
<!-- The Modal -->
<div class="modal" id="post-wish-canopy-modal-id">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Post Wish Canopy</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form role="form" action="{{ route('admin.postwish-canopy-submit-new') }}" enctype='multipart/form-data' method="POST">
        @csrf
            <div class="form-group">
                <label for="piller-post-id">Piller Post:</label>
                <select class="form-control" required name="piller_post_name" id="piller-post-id">
                    <option value="">Choose piller type</option>
                </select>
            </div>
            <div class="form-group">
                <label for="video-links-id">Video File: <b class="text-danger">( file size not more than 2mb * )</b></label>
                <input type="file"  name="canopy_video_file_name" required class="form-control" placeholder="Enter the video links" id="video-links-id" >
            </div>
            <div class="form-group">
                <label for="canopy-description-id">Description:</label>
                <textarea  name="canopy_description_name" required class="form-control" placeholder="Enter the descriptions" id="canopy-description-id" rows=5></textarea>
            </div>
            <input type="submit" class="btn btn-primary" name="submit" value="Submit" />
        </form>
      </div>


    </div>
  </div>
</div>
<!-- /post wish canopy model -->
<!-- Edit Post Wish Canopy Model -->
<!-- The Modal -->
<div class="modal" id="edit-post-wish-canopy-modal-id">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Edit Post Wish Canopy</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form role="form" action="{{ route('admin.postwish-canopy-submit-update') }}" enctype='multipart/form-data' method="POST">
        @csrf
          <input type="hidden" name="canopy_name_hidden_id" id="canopy-name-hidden-id" value="" /> 
            <div class="form-group">
                <label for="piller-post-id">Piller Post:</label>
                <select class="form-control" required name="edit_piller_post_name" id="edit-piller-post-id">
                    <option value="">Choose piller type</option>
                </select>
            </div>
            <div class="form-group">
                <label for="video-links-id">Video File: <b class="text-danger">( file size not more than 2mb * )</b></label>
                <input type="file"  name="edit_canopy_video_file_name" class="form-control" placeholder="Enter the video links" id="video-links-id" >
            </div>
            <div class="form-group">
                <label for="canopy-description-id">Description:</label>
                <textarea  name="edit_canopy_description_name" required class="form-control" placeholder="Enter the descriptions" id="edit-canopy-description-id" rows=5></textarea>
            </div>
            <input type="submit" class="btn btn-primary" name="submit" value="Submit" />
        </form>
      </div>


    </div>
  </div>
</div>
<!-- /post wish canopy model -->
@endsection
@section('adminjsContent')
<script>
    $(function(){
        load_canopy_video_fx();
        load_piller_post_fx();
    });

    function add_post_wish_canopy_fx()
    {
        $("#post-wish-canopy-modal-id").modal('show');
    }

    function load_canopy_video_fx()
    {
        $.ajax({
            url: "{{ route('admin.load-canopy-post-wish-fx') }}",
            type: "GET",
            dataType: "json",
            success: function(event){
                $("#canopy-tbl-id").html(event.canopy_html);
            }, error: function(event){

            }
        })
    }

    function load_piller_post_fx()
    {
        $.ajax({
            url: "{{ route('admin.load-piller-post-for-wish-canopy') }}",
            type: "GET",
            dataType: "json",
            success: function(event){
                $("#piller-post-id").html(event.piller_html);
            }, error: function(event){

            }
        });
    }


    function canopy_edit_fx(id)
    {
      $("#edit-post-wish-canopy-modal-id").modal('show');
      $("#canopy-name-hidden-id").val(id);
      $.ajax({
        url: "{{ route('admin.canopy-edit-fx') }}",
        type: "GET",
        data: {edit_id: id},
        dataType: "json",
        success: function(e)
        {
            $("#edit-piller-post-id").html(e.piller_html);
            $("#edit-canopy-description-id").html(e.description);
        }, error: function(e)
        {

        }
      })
    }


    function canopy_del_fx(id)
    {
      var x = confirm('Are you sure to delete this?');
      if(x)
      {
        $.ajax({
          url: "{{ route('admin.canopy-del-fx') }}",
          type: "GET",
          data: {edit_id: id},
          dataType: "json",
          success: function(event){
            if(event == "success_msg")
            {
              var alert_msg = "Successfully deleted";
              success_pass_alert_show_msg(alert_msg);
              location.reload();
            }
            else if(event == "error_msg")
            {
              var alert_msg = "Something wrong! Try again later";
              error_pass_alert_show_msg(alert_msg);
            }
          }, error: function(event){

          }
        })
      }
      else
      {

      }
    }

    
</script>
@endsection