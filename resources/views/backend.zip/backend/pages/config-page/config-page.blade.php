@extends('backend.app')
@section('content')
<section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Config Panel</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
            <li class="breadcrumb-item active">Config Panel</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
</section>
  <!-- Main content -->
  <section class="content">
        <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
            
            <div class="card card-success">
                <div style="padding: 50px">
                    <ul class="nav nav-pills" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="pill" href="#home">Pick A Footprint</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#pick-overhead-shades-id">Pick Overhead Shades</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#pick-post-length-id">Pick Post Length</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#pick-canopy-id">Canopy</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#pick-mount-bracket-id">Mount Brackets</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#pick-louvered-panel-id">Louvered Panel</a>
                        </li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div id="home" class="container tab-pane active"><br>
                            <h3>Pick a footprint</h3>
                            <ul class="nav nav-pills" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" data-toggle="pill" href="#home-sub">For 4 posts</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="pill" href="#menu1-sub">For 6 posts</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="pill" href="#menu2-sub">For 4 double posts</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="pill" href="#menu3-sub">For 8 posts</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div id="home-sub" class="container tab-pane active"><br>
                                    <!-- 4 post -->
                                    <form action="">
                                        <div class="form-group">
                                            <label for="four-sqft-price-id">Each Sqft. Price ( for 4 post):</label>
                                            <input type="email" class="form-control" id="four-sqft-price-id" placeholder="Enter price" name="four_sqft_price_name">
                                        </div>
                                        
                                        <input type="button" class="btn btn-primary" onclick="submit_config_four_sqft_fx()" value="Submit">
                                    </form>
                                </div>
                                <div id="menu1-sub" class="container tab-pane fade"><br>
                                    <!-- 6 post -->
                                    <form action="">
                                        <div class="form-group">
                                            <label for="six-sqft-price-id">Each Sqft. Price ( for 6 post):</label>
                                            <input type="email" class="form-control" id="six-sqft-price-id" placeholder="Enter price" name="six_sqft_price_name">
                                        </div>
                                        
                                        <input type="button" class="btn btn-primary" onclick="submit_config_six_sqft_fx()" value="Submit" />
                                    </form>
                                </div>
                                <div id="menu2-sub" class="container tab-pane fade"><br>
                                    <!-- 6 post -->
                                    <form action="">
                                        <div class="form-group">
                                            <label for="four-double-sqft-price-id">Price for 4 double post:</label>
                                            <input type="email" class="form-control" id="four-double-sqft-price-id" placeholder="Enter price" name="four_double_sqft_price_name">
                                        </div>
                                        
                                        <input type="button" class="btn btn-primary" onclick="submit_config_four_double_sqft_fx()" value="Submit" />
                                    </form>
                                </div>
                                <div id="menu3-sub" class="container tab-pane fade"><br>
                                    <!-- 6 post -->
                                    <form action="">
                                        <div class="form-group">
                                            <label for="eight-sqft-price-id">Price for 8 post:</label>
                                            <input type="email" class="form-control" id="eight-sqft-price-id" placeholder="Enter price" name="eight_sqft_price_name">
                                        </div>
                                        
                                        <input type="button" class="btn btn-primary" onclick="submit_config_eight_sqft_fx()" value="Submit" />
                                    </form>
                                </div>
                            </div>
                            
                            
                        </div>
                        <div id="pick-overhead-shades-id" class="container tab-pane fade"><br>
                            <h3>Pick Overhead Shades</h3>
                            <ul class="nav nav-pills" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" data-toggle="pill" href="#overhead-regular-id">For regular overhead shades</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="pill" href="#overhead-open-id">For open overhead shades</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="pill" href="#overhead-sunblocker-id">For sunblocker overhead shades</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div id="overhead-regular-id" class="container tab-pane active"><br>
                                    <!-- 4 post -->
                                    <form action="">
                                        <div class="form-group">
                                            <label for="regular-percentage-price-id">Regular % on price:</label>
                                            <input type="email" class="form-control" id="regular-percentage-price-id" placeholder="Enter % on price" name="regular_percentage_name">
                                        </div>
                                        
                                        <input type="button" class="btn btn-primary" onclick="submit_regular_price_fx()" value="Submit">
                                    </form>
                                </div>
                                <div id="overhead-open-id" class="container tab-pane fade"><br>
                                    <!-- 6 post -->
                                    <form action="">
                                        <div class="form-group">
                                            <label for="six-sqft-price-id">Open % on price:</label>
                                            <input type="email" class="form-control" id="open-percentage-price-id" placeholder="Enter % on price" name="open_percentage_name">
                                        </div>
                                        
                                        <input type="button" class="btn btn-primary" onclick="submit_open_price_fx()" value="Submit" />
                                    </form>
                                </div>
                                <div id="overhead-sunblocker-id" class="container tab-pane fade"><br>
                                    <!-- 6 post -->
                                    <form action="">
                                        <div class="form-group">
                                            <label for="six-sqft-price-id">Sunblocker % on price:</label>
                                            <input type="email" class="form-control" id="sunblocker-percentage-price-id" placeholder="Enter % on price" name="sunblocker_percentage_name">
                                        </div>
                                        
                                        <input type="button" class="btn btn-primary" onclick="submit_sunblocker_price_fx()" value="Submit" />
                                    </form>
                                </div>
                            </div>

                        </div>
                        <div id="pick-post-length-id" class="container tab-pane fade"><br>
                            <h3>Pick Post Length</h3>
                            <ul class="nav nav-pills" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" data-toggle="pill" href="#postLength9-id">For 9 ft. post length</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="pill" href="#postLength12-id">For 12 ft. post length</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div id="postLength9-id" class="container tab-pane active"><br>
                                    <!-- 4 post -->
                                    <form action="">
                                        <div class="form-group">
                                            <label for="post-length9-price-id">Price for 9 ft. post length:</label>
                                            <input type="text" class="form-control" id="post-length9-price-id" placeholder="Enter price" name="post_length9_price_name">
                                        </div>
                                        
                                        <input type="button" class="btn btn-primary" onclick="submit_config_post_length9_fx()" value="Submit">
                                    </form>
                                </div>
                                <div id="postLength12-id" class="container tab-pane fade"><br>
                                    <!-- 6 post -->
                                    <form action="">
                                        <div class="form-group">
                                            <label for="post-length12-price-id">Price for 12 ft. post length:</label>
                                            <input type="text" class="form-control" id="post-length12-price-id" placeholder="Enter price" name="post_length12_price_name">
                                        </div>
                                        
                                        <input type="button" class="btn btn-primary" onclick="submit_config_post_length12_fx()" value="Submit" />
                                    </form>
                                </div>
                            </div>

                        </div>

                        <div id="pick-canopy-id" class="container tab-pane fade"><br>
                            <h3>Pick Canopy</h3>
                            <ul class="nav nav-pills" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" data-toggle="pill" href="#canopy-id">Price for Canopy</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div id="canopy-id" class="container tab-pane active"><br>
                                    <!-- 4 post -->
                                    <form action="">
                                        <div class="form-group">
                                            <label for="canopy-price-id">Price for canopy:</label>
                                            <input type="text" class="form-control" id="canopy-price-id" placeholder="Enter price" name="canopy_name">
                                        </div>
                                        
                                        <input type="button" class="btn btn-primary" onclick="submit_config_canopy_fx()" value="Submit">
                                    </form>
                                </div>
                            </div>

                        </div>


                        <div id="pick-mount-bracket-id" class="container tab-pane fade"><br>
                            <h3>Pick Mount Bracket</h3>
                            <ul class="nav nav-pills" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" data-toggle="pill" href="#mount-post4-id">For 4 mount bracket</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="pill" href="#mount-post6-id">For 6 mount bracket</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="pill" href="#mount-post8-id">For 8 mount bracket</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div id="mount-post4-id" class="container tab-pane active"><br>
                                    <!-- 4 post -->
                                    <form action="">
                                        <div class="form-group">
                                            <label for="post-mount4-price-id">Price for 4 mount brackets:</label>
                                            <input type="text" class="form-control" id="post-mount4-price-id" placeholder="Enter price" name="post_mount4_price_name">
                                        </div>
                                        
                                        <input type="button" class="btn btn-primary" onclick="submit_config_mount4_fx()" value="Submit">
                                    </form>
                                </div>
                                <div id="mount-post6-id" class="container tab-pane"><br>
                                    <!-- 6 post -->
                                    <form action="">
                                        <div class="form-group">
                                            <label for="post-mount6-price-id">Price for 6 mount brackets:</label>
                                            <input type="text" class="form-control" id="post-mount6-price-id" placeholder="Enter price" name="post_mount6_price_name">
                                        </div>
                                        
                                        <input type="button" class="btn btn-primary" onclick="submit_config_mount6_fx()" value="Submit">
                                    </form>
                                </div>
                                <div id="mount-post8-id" class="container tab-pane"><br>
                                    <!-- 8 post -->
                                    <form action="">
                                        <div class="form-group">
                                            <label for="post-mount8-price-id">Price for 8 mount brackets:</label>
                                            <input type="text" class="form-control" id="post-mount8-price-id" placeholder="Enter price" name="post_mount8_price_name">
                                        </div>
                                        
                                        <input type="button" class="btn btn-primary" onclick="submit_config_mount8_fx()" value="Submit">
                                    </form>
                                </div>
                            </div>

                        </div>

                        <div id="pick-louvered-panel-id" class="container tab-pane fade"><br>
                            <h3>Pick Louvered Panel</h3>
                            <ul class="nav nav-pills" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" data-toggle="pill" href="#lpanel-id">Price for Louvered</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div id="lpanel-id" class="container tab-pane active"><br>
                                    <!-- 4 post -->
                                    <form action="">
                                        <div class="form-group">
                                            <label for="lpanel-price-id">Price in each sqft.:</label>
                                            <input type="text" class="form-control" id="lpanel-price-id" placeholder="Enter price" name="lpanel_name">
                                        </div>
                                        
                                        <input type="button" class="btn btn-primary" onclick="submit_config_lpanel_fx()" value="Submit">
                                    </form>
                                </div>
                            </div>

                        </div>



                    </div>

                    
                </div>
                </div>
                
            </div>
        </div>
            
    </div>
</section>
  <!-- /.content -->
@endsection
@section('adminjsContent')
<script>
    $(function(){
        load_pick_a_footprint_fx();
    });

    function submit_config_lpanel_fx()
    {
        var price_val = $("#lpanel-price-id").val();

        if(price_val == null || price_val == "")
        {
            msg = "Price can't be null";
            error_pass_alert_show_msg(msg);
        }
        else if(price_val == 0)
        {
            msg = "Price can't be zero";
            error_pass_alert_show_msg(msg);
        }
        else
        {
            $.ajax({
                url: "{{ route('admin.submit-louvered-panel-config') }}",
                type: "GET",
                data: {price_val: price_val},
                dataType: "json",
                success: function(event){
                    if(event == "success")
                    {
                        msg = "Successfully Added the amount";
                        success_pass_alert_show_msg(msg);
                        load_pick_a_footprint_fx();
                    }
                    else if(event == "error")
                    {
                        msg = "Something went wrong! try again";
                        error_pass_alert_show_msg(msg);
                    }
                }, error: function(event){

                }
            });

        }
    }

    // mount bracket
    // 4 mount bracket
    function submit_config_mount4_fx()
    {
        var price_val = $("#post-mount4-price-id").val();

        if(price_val == null || price_val == "")
        {
            msg = "Price can't be null";
            error_pass_alert_show_msg(msg);
        }
        else if(price_val == 0)
        {
            msg = "Price can't be zero";
            error_pass_alert_show_msg(msg);
        }
        else
        {
            $.ajax({
                url: "{{ route('admin.submit-mount4-config') }}",
                type: "GET",
                data: {price_val: price_val},
                dataType: "json",
                success: function(event){
                    if(event == "success")
                    {
                        msg = "Successfully Added the amount";
                        success_pass_alert_show_msg(msg);
                        load_pick_a_footprint_fx();
                    }
                    else if(event == "error")
                    {
                        msg = "Something went wrong! try again";
                        error_pass_alert_show_msg(msg);
                    }
                }, error: function(event){

                }
            });

        }
    }

    // 6 mount bracket
    function submit_config_mount6_fx()
    {
        var price_val = $("#post-mount6-price-id").val();

        if(price_val == null || price_val == "")
        {
            msg = "Price can't be null";
            error_pass_alert_show_msg(msg);
        }
        else if(price_val == 0)
        {
            msg = "Price can't be zero";
            error_pass_alert_show_msg(msg);
        }
        else
        {
            $.ajax({
                url: "{{ route('admin.submit-mount6-config') }}",
                type: "GET",
                data: {price_val: price_val},
                dataType: "json",
                success: function(event){
                    if(event == "success")
                    {
                        msg = "Successfully Added the amount";
                        success_pass_alert_show_msg(msg);
                        load_pick_a_footprint_fx();
                    }
                    else if(event == "error")
                    {
                        msg = "Something went wrong! try again";
                        error_pass_alert_show_msg(msg);
                    }
                }, error: function(event){

                }
            });

        }
    }

    // 8 mount bracket
    function submit_config_mount8_fx()
    {
        var price_val = $("#post-mount8-price-id").val();

        if(price_val == null || price_val == "")
        {
            msg = "Price can't be null";
            error_pass_alert_show_msg(msg);
        }
        else if(price_val == 0)
        {
            msg = "Price can't be zero";
            error_pass_alert_show_msg(msg);
        }
        else
        {
            $.ajax({
                url: "{{ route('admin.submit-mount8-config') }}",
                type: "GET",
                data: {price_val: price_val},
                dataType: "json",
                success: function(event){
                    if(event == "success")
                    {
                        msg = "Successfully Added the amount";
                        success_pass_alert_show_msg(msg);
                        load_pick_a_footprint_fx();
                    }
                    else if(event == "error")
                    {
                        msg = "Something went wrong! try again";
                        error_pass_alert_show_msg(msg);
                    }
                }, error: function(event){

                }
            });

        }
    }
    // canopy
    function submit_config_canopy_fx()
    {
        var price_val = $("#canopy-price-id").val();

        if(price_val == null || price_val == "")
        {
            msg = "Price can't be null";
            error_pass_alert_show_msg(msg);
        }
        else if(price_val == 0)
        {
            msg = "Price can't be zero";
            error_pass_alert_show_msg(msg);
        }
        else
        {
            $.ajax({
                url: "{{ route('admin.submit-canopy-config') }}",
                type: "GET",
                data: {price_val: price_val},
                dataType: "json",
                success: function(event){
                    if(event == "success")
                    {
                        msg = "Successfully Added the amount";
                        success_pass_alert_show_msg(msg);
                        load_pick_a_footprint_fx();
                    }
                    else if(event == "error")
                    {
                        msg = "Something went wrong! try again";
                        error_pass_alert_show_msg(msg);
                    }
                }, error: function(event){

                }
            });

        }
    }

    // post length
    function submit_config_post_length9_fx()
    {
        var price_val = $("#post-length9-price-id").val();

        if(price_val == null || price_val == "")
        {
            msg = "Price can't be null";
            error_pass_alert_show_msg(msg);
        }
        else if(price_val == 0)
        {
            msg = "Price can't be zero";
            error_pass_alert_show_msg(msg);
        }
        else
        {
            $.ajax({
                url: "{{ route('admin.submit-post9length-config') }}",
                type: "GET",
                data: {price_val: price_val},
                dataType: "json",
                success: function(event){
                    if(event == "success")
                    {
                        msg = "Successfully Added the amount";
                        success_pass_alert_show_msg(msg);
                        load_pick_a_footprint_fx();
                    }
                    else if(event == "error")
                    {
                        msg = "Something went wrong! try again";
                        error_pass_alert_show_msg(msg);
                    }
                }, error: function(event){

                }
            });

        }
    }

    function submit_config_post_length12_fx()
    {
        var price_val = $("#post-length12-price-id").val();

        if(price_val == null || price_val == "")
        {
            msg = "Price can't be null";
            error_pass_alert_show_msg(msg);
        }
        else if(price_val == 0)
        {
            msg = "Price can't be zero";
            error_pass_alert_show_msg(msg);
        }
        else
        {
            $.ajax({
                url: "{{ route('admin.submit-post12length-config') }}",
                type: "GET",
                data: {price_val: price_val},
                dataType: "json",
                success: function(event){
                    if(event == "success")
                    {
                        msg = "Successfully Added the amount";
                        success_pass_alert_show_msg(msg);
                        load_pick_a_footprint_fx();
                    }
                    else if(event == "error")
                    {
                        msg = "Something went wrong! try again";
                        error_pass_alert_show_msg(msg);
                    }
                }, error: function(event){

                }
            });

        }
    }

    // pick a footprint
    function submit_config_four_double_sqft_fx()
    {
        var price_val = $("#four-double-sqft-price-id").val();

        if(price_val == null || price_val == "")
        {
            msg = "Price can't be null";
            error_pass_alert_show_msg(msg);
        }
        else if(price_val == 0)
        {
            msg = "Price can't be zero";
            error_pass_alert_show_msg(msg);
        }
        else
        {
            $.ajax({
                url: "{{ route('admin.submit-4double-post-config') }}",
                type: "GET",
                data: {price_val: price_val},
                dataType: "json",
                success: function(event){
                    if(event == "success")
                    {
                        msg = "Successfully Added the amount";
                        success_pass_alert_show_msg(msg);
                        load_pick_a_footprint_fx();
                    }
                    else if(event == "error")
                    {
                        msg = "Something went wrong! try again";
                        error_pass_alert_show_msg(msg);
                    }
                }, error: function(event){

                }
            });

        }
    }

    function submit_config_eight_sqft_fx()
    {
        var price_val = $("#eight-sqft-price-id").val();

        if(price_val == null || price_val == "")
        {
            msg = "Price can't be null";
            error_pass_alert_show_msg(msg);
        }
        else if(price_val == 0)
        {
            msg = "Price can't be zero";
            error_pass_alert_show_msg(msg);
        }
        else
        {
            $.ajax({
                url: "{{ route('admin.submit-8post-config') }}",
                type: "GET",
                data: {price_val: price_val},
                dataType: "json",
                success: function(event){
                    if(event == "success")
                    {
                        msg = "Successfully Added the amount";
                        success_pass_alert_show_msg(msg);
                        load_pick_a_footprint_fx();
                    }
                    else if(event == "error")
                    {
                        msg = "Something went wrong! try again";
                        error_pass_alert_show_msg(msg);
                    }
                }, error: function(event){

                }
            });

        }
    }


    function submit_config_four_sqft_fx()
    {
        var price_val = $("#four-sqft-price-id").val();

        if(price_val == null || price_val == "")
        {
            msg = "Price can't be null";
            error_pass_alert_show_msg(msg);
        }
        else if(price_val == 0)
        {
            msg = "Price can't be zero";
            error_pass_alert_show_msg(msg);
        }
        else
        {
            $.ajax({
                url: "{{ route('admin.submit-4post-config') }}",
                type: "GET",
                data: {price_val: price_val},
                dataType: "json",
                success: function(event){
                    if(event == "success")
                    {
                        msg = "Successfully Added the amount";
                        success_pass_alert_show_msg(msg);
                        load_pick_a_footprint_fx();
                    }
                    else if(event == "error")
                    {
                        msg = "Something went wrong! try again";
                        error_pass_alert_show_msg(msg);
                    }
                }, error: function(event){

                }
            });

        }
    }

    function submit_config_six_sqft_fx()
    {
        var price_val = $("#six-sqft-price-id").val();

        if(price_val == null || price_val == "")
        {
            msg = "Price can't be null";
            error_pass_alert_show_msg(msg);
        }
        else if(price_val == 0)
        {
            msg = "Price can't be zero";
            error_pass_alert_show_msg(msg);
        }
        else
        {
            $.ajax({
                url: "{{ route('admin.submit-6post-config') }}",
                type: "GET",
                data: {price_val: price_val},
                dataType: "json",
                success: function(event){
                    if(event == "success")
                    {
                        msg = "Successfully Added the amount";
                        success_pass_alert_show_msg(msg);
                        load_pick_a_footprint_fx();
                    }
                    else if(event == "error")
                    {
                        msg = "Something went wrong! try again";
                        error_pass_alert_show_msg(msg);
                    }
                }, error: function(event){

                }
            });

        }
    }


    function load_pick_a_footprint_fx()
    {
        
        $.ajax({
            url: "{{ route('admin.admin-config-page-show-load') }}",
            type: "GET",
            dataType: "json",
            success: function(event){
                console.log(event);
                if(event.msg_state == "success")
                {
                    if(event.msg_post4 == 0)
                    {
                        var p4 = "";
                    }
                    else
                    {
                        var p4 = event.msg_post4;
                    }

                    if(event.msg_post6 == 0)
                    {
                        var p6 = "";
                    }
                    else
                    {
                        var p6 = event.msg_post6;
                    }

                    if(event.msg_post4d == 0)
                    {
                        var p4d = "";
                    }
                    else
                    {
                        var p4d = event.msg_post4d;
                    }

                    if(event.msg_post8 == 0)
                    {
                        var p8 = "";
                    }
                    else
                    {
                        var p8 = event.msg_post8;
                    }

                    
                    $("#four-sqft-price-id").val(p4);
                    $("#six-sqft-price-id").val(p6);
                    $("#four-double-sqft-price-id").val(p4d);
                    $("#eight-sqft-price-id").val(p8);
                }
                else if(event.msg_state == "error")
                {
                    
                }


                if(event.shades_msg_state == "success")
                {
                    
                        var regular = event.regular_price;
                    

                    if(event.open_price == 0)
                    {
                        var open = "";
                    }
                    else
                    {
                        var open = event.open_price;
                    }

                    if(event.sunblocker_price == 0)
                    {
                        var sunblocker = "";
                    }
                    else
                    {
                        var sunblocker = event.sunblocker_price;
                    }
                    $("#regular-percentage-price-id").val(regular);
                    $("#open-percentage-price-id").val(open);
                    $("#sunblocker-percentage-price-id").val(sunblocker);
                }
                else if(event.shades_msg_state == "error")
                {
                    
                }

                if(event.post_msg_state == "success")
                {
                    if(event.postlength9_price == 0)
                    {
                        var post_length9_price = "";
                    }
                    else
                    {
                        var post_length9_price = event.postlength9_price;
                    }

                    if(event.postlength12_price == 0)
                    {
                        var post_length12_price = "";
                    }
                    else
                    {
                        var post_length12_price = event.postlength12_price;
                    }
                    $("#post-length9-price-id").val(post_length9_price);
                    $("#post-length12-price-id").val(post_length12_price);
                }
                else if(event.post_msg_state == "error")
                {
                    
                }

                if(event.canopy_msg_state == "success")
                {
                    if(event.canopy_price == 0)
                    {
                        var canopy_price = "";
                    }
                    else
                    {
                        var canopy_price = event.canopy_price;
                    }
                    $("#canopy-price-id").val(canopy_price);
                }
                else if(event.canopy_msg_state == "error")
                {
                    
                }
                

                if(event.post_msg_mount == "success")
                {
                    if(event.mount_bracket4_price == 0)
                    {
                        var mount_bracket4_price = "";
                    }
                    else
                    {
                        var mount_bracket4_price = event.mount_bracket4_price;
                    }

                    if(event.mount_bracket6_price == 0)
                    {
                        var mount_bracket6_price = "";
                    }
                    else
                    {
                        var mount_bracket6_price = event.mount_bracket6_price;
                    }

                    if(event.mount_bracket8_price == 0)
                    {
                        var mount_bracket8_price = "";
                    }
                    else
                    {
                        var mount_bracket8_price = event.mount_bracket8_price;
                    }
                    $("#post-mount4-price-id").val(mount_bracket4_price);
                    $("#post-mount6-price-id").val(mount_bracket6_price);
                    $("#post-mount8-price-id").val(mount_bracket8_price);
                }
                else if(event.post_msg_mount == "error")
                {
                    
                }


                
                if(event.post_msg_lpanel == "success")
                {
                    if(event.each_sqft_price == 0)
                    {
                        var each_sqft_price = "";
                    }
                    else
                    {
                        var each_sqft_price = event.each_sqft_price;
                    }
                    $("#lpanel-price-id").val(each_sqft_price);
                }
                else if(event.canopy_msg_state == "error")
                {
                    
                }
            }, error: function(event){

            }
        })
    }

    // end of pck a footprint

    // Overhead shades
    function submit_regular_price_fx()
    {
        var price_val = $("#regular-percentage-price-id").val();

        if(price_val == null || price_val == "")
        {
            msg = "Price can't be null";
            error_pass_alert_show_msg(msg);
        }
        else
        {
            $.ajax({
                url: "{{ route('admin.submit-regular-config') }}",
                type: "GET",
                data: {price_val: price_val},
                dataType: "json",
                success: function(event){
                    if(event == "success")
                    {
                        msg = "Successfully Added the amount";
                        success_pass_alert_show_msg(msg);
                        load_pick_a_footprint_fx();
                    }
                    else if(event == "error")
                    {
                        msg = "Something went wrong! try again";
                        error_pass_alert_show_msg(msg);
                    }
                }, error: function(event){

                }
            });

        }
    }

    function submit_open_price_fx()
    {
        var price_val = $("#open-percentage-price-id").val();

        if(price_val == null || price_val == "")
        {
            msg = "Price can't be null";
            error_pass_alert_show_msg(msg);
        }
        else if(price_val == 0)
        {
            msg = "Price can't be zero";
            error_pass_alert_show_msg(msg);
        }
        else
        {
            $.ajax({
                url: "{{ route('admin.submit-open-config') }}",
                type: "GET",
                data: {price_val: price_val},
                dataType: "json",
                success: function(event){
                    if(event == "success")
                    {
                        msg = "Successfully Added the amount";
                        success_pass_alert_show_msg(msg);
                        load_pick_a_footprint_fx();
                    }
                    else if(event == "error")
                    {
                        msg = "Something went wrong! try again";
                        error_pass_alert_show_msg(msg);
                    }
                }, error: function(event){

                }
            });

        }
    }

    function submit_sunblocker_price_fx()
    {
        var price_val = $("#sunblocker-percentage-price-id").val();

        if(price_val == null || price_val == "")
        {
            msg = "Price can't be null";
            error_pass_alert_show_msg(msg);
        }
        else if(price_val == 0)
        {
            msg = "Price can't be zero";
            error_pass_alert_show_msg(msg);
        }
        else
        {
            $.ajax({
                url: "{{ route('admin.submit-sunblocker-config') }}",
                type: "GET",
                data: {price_val: price_val},
                dataType: "json",
                success: function(event){
                    if(event == "success")
                    {
                        msg = "Successfully Added the amount";
                        success_pass_alert_show_msg(msg);
                        load_pick_a_footprint_fx();
                    }
                    else if(event == "error")
                    {
                        msg = "Something went wrong! try again";
                        error_pass_alert_show_msg(msg);
                    }
                }, error: function(event){

                }
            });

        }
    }
    // end of overshades 
</script>
@endsection